
-- Already have search_path set, but linter wants explicit. Re-create with explicit set.
-- The main fix is revoking execute from public/authenticated on definer functions.
revoke execute on function public.has_role(uuid, public.app_role) from public, anon, authenticated;
revoke execute on function public.is_project_member(uuid, uuid) from public, anon, authenticated;
revoke execute on function public.handle_new_user() from public, anon, authenticated;
revoke execute on function public.set_updated_at() from public, anon, authenticated;
