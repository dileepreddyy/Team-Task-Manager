
-- Roles enum
create type public.app_role as enum ('admin', 'member');

-- Task status enum
create type public.task_status as enum ('pending', 'in_progress', 'done');

-- Profiles
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text,
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

-- User roles (separate table per security best practice)
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  created_at timestamptz not null default now(),
  unique(user_id, role)
);
alter table public.user_roles enable row level security;

-- Security definer role check
create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.user_roles where user_id = _user_id and role = _role
  )
$$;

-- Projects
create table public.projects (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  owner_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.projects enable row level security;

-- Project members
create table public.project_members (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(project_id, user_id)
);
alter table public.project_members enable row level security;

-- Membership check function (avoids recursion)
create or replace function public.is_project_member(_user_id uuid, _project_id uuid)
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.project_members
    where user_id = _user_id and project_id = _project_id
  ) or exists (
    select 1 from public.projects where id = _project_id and owner_id = _user_id
  )
$$;

-- Tasks
create table public.tasks (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  title text not null,
  description text,
  status public.task_status not null default 'pending',
  deadline timestamptz,
  assignee_id uuid references auth.users(id) on delete set null,
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.tasks enable row level security;

-- ===== RLS Policies =====

-- profiles: signed-in users can read all (needed for assignee dropdowns); users can update their own
create policy "profiles select all authenticated"
  on public.profiles for select to authenticated using (true);
create policy "profiles update own"
  on public.profiles for update to authenticated using (auth.uid() = id);
create policy "profiles insert own"
  on public.profiles for insert to authenticated with check (auth.uid() = id);

-- user_roles: users can read their own roles; nobody can insert/update/delete via API (handled by triggers/admin)
create policy "user_roles select own"
  on public.user_roles for select to authenticated using (auth.uid() = user_id);
create policy "user_roles admin select all"
  on public.user_roles for select to authenticated using (public.has_role(auth.uid(), 'admin'));

-- projects
create policy "projects select members or admin"
  on public.projects for select to authenticated
  using (public.is_project_member(auth.uid(), id) or public.has_role(auth.uid(), 'admin'));
create policy "projects insert admin"
  on public.projects for insert to authenticated
  with check (public.has_role(auth.uid(), 'admin') and owner_id = auth.uid());
create policy "projects update admin"
  on public.projects for update to authenticated
  using (public.has_role(auth.uid(), 'admin'));
create policy "projects delete admin"
  on public.projects for delete to authenticated
  using (public.has_role(auth.uid(), 'admin'));

-- project_members
create policy "project_members select members or admin"
  on public.project_members for select to authenticated
  using (public.is_project_member(auth.uid(), project_id) or public.has_role(auth.uid(), 'admin'));
create policy "project_members insert admin"
  on public.project_members for insert to authenticated
  with check (public.has_role(auth.uid(), 'admin'));
create policy "project_members delete admin"
  on public.project_members for delete to authenticated
  using (public.has_role(auth.uid(), 'admin'));

-- tasks
create policy "tasks select members or admin"
  on public.tasks for select to authenticated
  using (public.is_project_member(auth.uid(), project_id) or public.has_role(auth.uid(), 'admin'));
create policy "tasks insert admin"
  on public.tasks for insert to authenticated
  with check (public.has_role(auth.uid(), 'admin'));
create policy "tasks update admin or assignee"
  on public.tasks for update to authenticated
  using (public.has_role(auth.uid(), 'admin') or assignee_id = auth.uid());
create policy "tasks delete admin"
  on public.tasks for delete to authenticated
  using (public.has_role(auth.uid(), 'admin'));

-- ===== Triggers =====

-- Auto-create profile + assign role on signup (first user = admin)
create or replace function public.handle_new_user()
returns trigger
language plpgsql security definer set search_path = public
as $$
declare
  user_count int;
  assigned_role public.app_role;
begin
  insert into public.profiles (id, full_name, email)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.email), new.email);

  select count(*) into user_count from public.user_roles;
  if user_count = 0 then
    assigned_role := 'admin';
  else
    assigned_role := 'member';
  end if;

  insert into public.user_roles (user_id, role) values (new.id, assigned_role);
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Updated_at trigger for tasks
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;

create trigger tasks_set_updated_at
  before update on public.tasks
  for each row execute function public.set_updated_at();
