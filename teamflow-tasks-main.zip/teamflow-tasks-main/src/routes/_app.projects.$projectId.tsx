import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Plus, Trash2, ArrowLeft, UserPlus, X, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { format, isPast } from "date-fns";

export const Route = createFileRoute("/_app/projects/$projectId")({
  head: () => ({ meta: [{ title: "Project — Team Task Manager" }] }),
  component: ProjectDetail,
});

type Project = { id: string; name: string; description: string | null; owner_id: string };
type Profile = { id: string; full_name: string | null; email: string | null };
type Task = {
  id: string;
  title: string;
  description: string | null;
  status: "pending" | "in_progress" | "done";
  deadline: string | null;
  assignee_id: string | null;
  profiles?: Profile | null;
};
type Member = { id: string; user_id: string; profiles: Profile | null };

const statusLabel = { pending: "Pending", in_progress: "In Progress", done: "Done" } as const;

function ProjectDetail() {
  const { projectId } = Route.useParams();
  const { user, role } = useAuth();
  const isAdmin = role === "admin";

  const [project, setProject] = useState<Project | null>(null);
  const [members, setMembers] = useState<Member[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [allProfiles, setAllProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);

  // Task dialog
  const [taskOpen, setTaskOpen] = useState(false);
  const [tTitle, setTTitle] = useState("");
  const [tDesc, setTDesc] = useState("");
  const [tDeadline, setTDeadline] = useState("");
  const [tAssignee, setTAssignee] = useState<string>("");
  const [tSaving, setTSaving] = useState(false);

  // Member dialog
  const [memberOpen, setMemberOpen] = useState(false);
  const [mUser, setMUser] = useState<string>("");

  const load = useCallback(async () => {
    setLoading(true);
    const [{ data: p }, { data: m }, { data: t }, { data: profs }] = await Promise.all([
      supabase.from("projects").select("*").eq("id", projectId).maybeSingle(),
      supabase
        .from("project_members")
        .select("id, user_id, profiles(id, full_name, email)")
        .eq("project_id", projectId),
      supabase
        .from("tasks")
        .select("*, profiles!tasks_assignee_id_fkey(id, full_name, email)")
        .eq("project_id", projectId)
        .order("created_at", { ascending: false }),
      supabase.from("profiles").select("id, full_name, email"),
    ]);
    setProject((p as Project) ?? null);
    setMembers((m as Member[] | null) ?? []);
    setTasks((t as Task[] | null) ?? []);
    setAllProfiles((profs as Profile[] | null) ?? []);
    setLoading(false);
  }, [projectId]);

  useEffect(() => {
    load();
  }, [load]);

  const addMember = async () => {
    if (!mUser) return;
    const { error } = await supabase
      .from("project_members")
      .insert({ project_id: projectId, user_id: mUser });
    if (error) return toast.error(error.message);
    toast.success("Member added");
    setMUser("");
    setMemberOpen(false);
    load();
  };

  const removeMember = async (id: string) => {
    const { error } = await supabase.from("project_members").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Member removed");
    load();
  };

  const createTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setTSaving(true);
    const { error } = await supabase.from("tasks").insert({
      project_id: projectId,
      title: tTitle,
      description: tDesc || null,
      deadline: tDeadline ? new Date(tDeadline).toISOString() : null,
      assignee_id: tAssignee || null,
      created_by: user.id,
    });
    setTSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Task created");
    setTTitle("");
    setTDesc("");
    setTDeadline("");
    setTAssignee("");
    setTaskOpen(false);
    load();
  };

  const updateStatus = async (id: string, status: Task["status"]) => {
    const { error } = await supabase.from("tasks").update({ status }).eq("id", id);
    if (error) return toast.error(error.message);
    load();
  };

  const deleteTask = async (id: string) => {
    if (!confirm("Delete this task?")) return;
    const { error } = await supabase.from("tasks").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Task deleted");
    load();
  };

  const memberOptions = allProfiles.filter(
    (p) =>
      !members.some((m) => m.user_id === p.id) && p.id !== project?.owner_id
  );
  // Assignable users = project members + owner
  const assignableUsers = [
    ...members.map((m) => m.profiles).filter(Boolean) as Profile[],
    ...(project ? allProfiles.filter((p) => p.id === project.owner_id) : []),
  ];

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!project) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <p>Project not found.</p>
          <Link to="/projects">
            <Button variant="link">Back to projects</Button>
          </Link>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <Link to="/projects" className="mb-2 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> All projects
        </Link>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{project.name}</h1>
            {project.description && (
              <p className="mt-1 text-muted-foreground">{project.description}</p>
            )}
          </div>
          {isAdmin && (
            <Dialog open={taskOpen} onOpenChange={setTaskOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <Plus className="h-4 w-4" /> New task
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create task</DialogTitle>
                  <DialogDescription>Assign work to a team member.</DialogDescription>
                </DialogHeader>
                <form onSubmit={createTask} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="t-title">Title</Label>
                    <Input id="t-title" value={tTitle} onChange={(e) => setTTitle(e.target.value)} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="t-desc">Description</Label>
                    <Textarea id="t-desc" value={tDesc} onChange={(e) => setTDesc(e.target.value)} rows={3} />
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="t-deadline">Deadline</Label>
                      <Input
                        id="t-deadline"
                        type="date"
                        value={tDeadline}
                        onChange={(e) => setTDeadline(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Assignee</Label>
                      <Select value={tAssignee} onValueChange={setTAssignee}>
                        <SelectTrigger>
                          <SelectValue placeholder="Unassigned" />
                        </SelectTrigger>
                        <SelectContent>
                          {assignableUsers.map((u) => (
                            <SelectItem key={u.id} value={u.id}>
                              {u.full_name || u.email}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="submit" disabled={tSaving}>
                      {tSaving ? "Creating..." : "Create task"}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <Card>
          <CardHeader>
            <CardTitle>Tasks ({tasks.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {tasks.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">No tasks yet.</p>
            ) : (
              <div className="space-y-2">
                {tasks.map((t) => {
                  const overdue =
                    t.status !== "done" && t.deadline && isPast(new Date(t.deadline));
                  const canUpdate = isAdmin || t.assignee_id === user?.id;
                  return (
                    <div
                      key={t.id}
                      className="flex flex-col gap-2 rounded-lg border bg-card p-4 sm:flex-row sm:items-center sm:justify-between"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-medium">{t.title}</span>
                          {overdue && <Badge variant="destructive">Overdue</Badge>}
                        </div>
                        {t.description && (
                          <p className="mt-1 text-sm text-muted-foreground">{t.description}</p>
                        )}
                        <div className="mt-1 text-xs text-muted-foreground">
                          {t.deadline && <span>Due {format(new Date(t.deadline), "MMM d, yyyy")}</span>}
                          {t.profiles?.full_name && (
                            <span> · {t.profiles.full_name}</span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {canUpdate ? (
                          <Select
                            value={t.status}
                            onValueChange={(v) => updateStatus(t.id, v as Task["status"])}
                          >
                            <SelectTrigger className="w-[140px]">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="pending">Pending</SelectItem>
                              <SelectItem value="in_progress">In Progress</SelectItem>
                              <SelectItem value="done">Done</SelectItem>
                            </SelectContent>
                          </Select>
                        ) : (
                          <Badge variant="secondary">{statusLabel[t.status]}</Badge>
                        )}
                        {isAdmin && (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteTask(t.id)}
                            title="Delete task"
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <CardTitle>Members ({members.length + 1})</CardTitle>
            {isAdmin && (
              <Dialog open={memberOpen} onOpenChange={setMemberOpen}>
                <DialogTrigger asChild>
                  <Button size="sm" variant="outline" className="gap-1">
                    <UserPlus className="h-4 w-4" /> Add
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add member</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <Select value={mUser} onValueChange={setMUser}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a user" />
                      </SelectTrigger>
                      <SelectContent>
                        {memberOptions.length === 0 ? (
                          <div className="p-2 text-sm text-muted-foreground">No users available</div>
                        ) : (
                          memberOptions.map((p) => (
                            <SelectItem key={p.id} value={p.id}>
                              {p.full_name || p.email}
                            </SelectItem>
                          ))
                        )}
                      </SelectContent>
                    </Select>
                    <DialogFooter>
                      <Button onClick={addMember} disabled={!mUser}>
                        Add to project
                      </Button>
                    </DialogFooter>
                  </div>
                </DialogContent>
              </Dialog>
            )}
          </CardHeader>
          <CardContent className="space-y-2">
            {/* Owner */}
            {allProfiles
              .filter((p) => p.id === project.owner_id)
              .map((p) => (
                <div key={p.id} className="flex items-center justify-between rounded-md border p-2">
                  <div className="text-sm">
                    <div className="font-medium">{p.full_name || p.email}</div>
                    <div className="text-xs text-muted-foreground">Owner</div>
                  </div>
                </div>
              ))}
            {members.map((m) => (
              <div key={m.id} className="flex items-center justify-between rounded-md border p-2">
                <div className="text-sm">
                  <div className="font-medium">{m.profiles?.full_name || m.profiles?.email}</div>
                  <div className="text-xs text-muted-foreground">Member</div>
                </div>
                {isAdmin && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removeMember(m.id)}
                    title="Remove"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
