import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle2, Clock, AlertTriangle, ListTodo, Loader2 } from "lucide-react";
import { format, isPast } from "date-fns";

export const Route = createFileRoute("/_app/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — Team Task Manager" }] }),
  component: Dashboard,
});

type Task = {
  id: string;
  title: string;
  description: string | null;
  status: "pending" | "in_progress" | "done";
  deadline: string | null;
  assignee_id: string | null;
  project_id: string;
  projects?: { name: string } | null;
  profiles?: { full_name: string | null; email: string | null } | null;
};

const statusLabel = { pending: "Pending", in_progress: "In Progress", done: "Done" } as const;
const statusVariant: Record<string, "secondary" | "default" | "outline"> = {
  pending: "secondary",
  in_progress: "default",
  done: "outline",
};

function Dashboard() {
  const { user, role } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>("all");

  const load = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("tasks")
      .select("*, projects(name), profiles!tasks_assignee_id_fkey(full_name, email)")
      .order("created_at", { ascending: false });
    setTasks((data as Task[] | null) ?? []);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const updateStatus = async (id: string, status: Task["status"]) => {
    await supabase.from("tasks").update({ status }).eq("id", id);
    load();
  };

  const total = tasks.length;
  const completed = tasks.filter((t) => t.status === "done").length;
  const pending = tasks.filter((t) => t.status !== "done").length;
  const overdue = tasks.filter(
    (t) => t.status !== "done" && t.deadline && isPast(new Date(t.deadline))
  ).length;

  const filtered = tasks.filter((t) => {
    if (filter === "all") return true;
    if (filter === "overdue")
      return t.status !== "done" && t.deadline && isPast(new Date(t.deadline));
    return t.status === filter;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Overview of all tasks across your projects</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={ListTodo} label="Total" value={total} tone="text-foreground" />
        <StatCard icon={Clock} label="Pending" value={pending} tone="text-amber-600" />
        <StatCard icon={CheckCircle2} label="Completed" value={completed} tone="text-emerald-600" />
        <StatCard icon={AlertTriangle} label="Overdue" value={overdue} tone="text-destructive" />
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <CardTitle>Tasks</CardTitle>
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All tasks</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="done">Done</SelectItem>
              <SelectItem value="overdue">Overdue</SelectItem>
            </SelectContent>
          </Select>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : filtered.length === 0 ? (
            <p className="py-12 text-center text-sm text-muted-foreground">
              No tasks match this filter.
            </p>
          ) : (
            <div className="space-y-2">
              {filtered.map((t) => {
                const isOverdue =
                  t.status !== "done" && t.deadline && isPast(new Date(t.deadline));
                const canUpdate = role === "admin" || t.assignee_id === user?.id;
                return (
                  <div
                    key={t.id}
                    className="flex flex-col gap-3 rounded-lg border bg-card p-4 sm:flex-row sm:items-center sm:justify-between"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-medium">{t.title}</span>
                        <Badge variant={statusVariant[t.status]}>{statusLabel[t.status]}</Badge>
                        {isOverdue && <Badge variant="destructive">Overdue</Badge>}
                      </div>
                      <div className="mt-1 text-sm text-muted-foreground">
                        {t.projects?.name && <span>{t.projects.name}</span>}
                        {t.deadline && (
                          <span> · Due {format(new Date(t.deadline), "MMM d, yyyy")}</span>
                        )}
                        {t.profiles?.full_name && (
                          <span> · Assigned to {t.profiles.full_name}</span>
                        )}
                      </div>
                    </div>
                    {canUpdate && (
                      <Select
                        value={t.status}
                        onValueChange={(v) => updateStatus(t.id, v as Task["status"])}
                      >
                        <SelectTrigger className="w-[150px]">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pending">Pending</SelectItem>
                          <SelectItem value="in_progress">In Progress</SelectItem>
                          <SelectItem value="done">Done</SelectItem>
                        </SelectContent>
                      </Select>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  tone,
}: {
  icon: typeof ListTodo;
  label: string;
  value: number;
  tone: string;
}) {
  return (
    <Card>
      <CardContent className="flex items-center gap-4 p-6">
        <div className={`rounded-lg bg-secondary p-3 ${tone}`}>
          <Icon className="h-5 w-5" />
        </div>
        <div>
          <div className="text-sm text-muted-foreground">{label}</div>
          <div className="text-2xl font-bold">{value}</div>
        </div>
      </CardContent>
    </Card>
  );
}
